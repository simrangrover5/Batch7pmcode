from flask import Flask,render_template,request
import pymysql 

app = Flask(__name__)


@app.route('/')
def index():
    return render_template("index.html")
    #return "Hello world"

@app.route('/<var>/')
def hello(var):
    return render_template("one.html",name=var)

@app.route('/about/<var>/<int:m>')
def about(var,m):
    dict = {
        'name' : var,
        'marks' : m
    }
    return render_template("one.html",data=dict)
    #return f"<h1 style='color:red'>Welcome to my world {var} with num {m}</h1><br><p>"

@app.route('/login/')
def login():
    return render_template("login.html")


@app.route('/signup/')
def signup():
    return render_template("signup.html")

@app.route('/login1/',methods=['GET','POST'])
def login1():
    email = request.form.get('email')
    password = request.form.get('pswd')
    return "<h1 style='color:red'>Welcome user with email {}</h1>".format(email)


@app.route('/signup1/',methods=['GET','POST'])
def signup1():
    password = request.form.get('pswd')
    cpassword = request.form.get('cpswd')
    if password == cpassword:
        email = request.form.get('email')
        file = request.form.get('myfile')
        try:
            db = sql.connect(host="localhost",port=3306,user="root",password="",database="abc")
            
        except Exception as e:
            c = db.cursor()
            cmd = "create database abc"
            c.execute(cmd)
        else:
            c = db.cursor()
            print("OK")


    else:
        error = "Invalid password"
        return render_template("signup.html",error=error)

app.run(host="localhost",port=80,debug=True)